<?php

$string['myspecialcourse:addinstance'] = 'Add a new My Special Course block';
$string['myspecialcourse:myaddinstance'] = 'Add a new My Special Course block to Dashboard';
$string['myspecialcourse'] = 'CNN Academy: My Special Course';
$string['pluginname'] = 'CNN Academy: My Special Courses';
$string['courseid'] = 'Special Course ID';
$string['title'] = 'Title';
$string['myresources'] = 'My Resources';
$string['coolstuff'] = 'Cool Stuff';