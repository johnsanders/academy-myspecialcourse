<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2020111802;
$plugin->requires  = 2020111202;
$plugin->component = 'block_myspecialcourse';
